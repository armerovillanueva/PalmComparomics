#!/usr/bin/env perl                                                                                                                                                        
use strict;
use warnings;
use Bio::Seq;
use Bio::SeqIO;
use Getopt::Long qw(GetOptions);


# Aim: Assemble overlapping sequences 
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                       # Versioning: 2017.1.28 



my $input = "" ;
my $output = "" ;
my $seqs= "" ;
my $redun = "" ;
my $new_redun  = "" ;

GetOptions (

         'i=s' => \$input, 
         's=s' => \$seqs,
         'o=s' => \$output,
         'r=s' => \$redun,
         'n=s' => \$new_redun, 
    )  or die "Usage:$0 -i input -s sequences -o output  -r input_redundancy -n new_redundancy \n" ;


  main :{

    if(  (-s $input) and ( -s $seqs  ) and ( -s $redun ) ){
	Parsing( $input, $seqs ,$output, $redun ,$new_redun);
          }
    else{
	die "Usage:$0 Non Files\n" ;
       }
    }



   sub Parsing { 

    my  ( $input, $seqs, $output, $redun, $new_redun) = @_;
 
      open(my $ip , '<', $input ) or die "Can't read file $input" ;      
      open(my $sq , '<', $seqs ) or die "Can't read file $seqs" ;
      open(my $rd , '<', $redun ) or die "Can't read file $redun" ;
      open(my $nr , '>', $new_redun ) or die "Can't read file $new_redun" ; 
      my $seqio_obj_Out = Bio::SeqIO->new(-file => ">$output", -format => 'fasta' );    

       my %Seqs ; 
       my $sec_final = "" ;     

       my %Redun_red ;
       my %Redun_rep ;

    while( my $ln = <$rd> ){
         chomp($ln);  
	my @ar = split(/\t/, $ln);

        $Redun_red{$ar[0]} = $ar[2] ;  
	$Redun_rep{$ar[0]} = $ar[1] ;

           }

  while( my $ln_sq = <$sq> ){

 	  chomp($ln_sq);
          my ($nm, $sc) =split(/\t/, $ln_sq );
          $Seqs{$nm}= $sc ;    

           }

    my %Reference ;
      
    while(my $ln = <$ip>){
   
        chomp($ln);  
        my @ar = split(/\t/, $ln); 
        my $id  = shift @ar ;
        my $str = join("\t", @ar) ;
        $Reference{$id}{$str} = "" ;

           }
        
    my @Refs = keys %Reference ;
    
    while(@Refs){
     
        my $rf = shift @Refs ;
	my @querys = keys %{$Reference{$rf}} ;
	my @pre = map { my @ar = split(/\t/, $_) ; \@ar  } @querys ; 
        my @ord = sort { $a -> [4] <=> $b -> [4]  } @pre ;
        my @new_ord ; 

   
          while(my $or = shift @ord){

                  my @od = @{$or} ;
                 push  @new_ord,join("\t", @od);
                
                    }            
     
          my $target_rf = shift @new_ord ;
          my @tr_tmp = split(/\t/,$target_rf ); 
             $tr_tmp[1]= 0;
             $tr_tmp[2] -= 1; 
   	    $target_rf = join("\t", @tr_tmp);
          my $seq_product = "" ; 
	 
           my @new_seq_red ;
         
           my @ent_seq ;   	  


$sec_final =  Extension($target_rf, \@new_ord, \%Seqs, $seq_product, \@new_seq_red, \@ent_seq);

       
        if($sec_final ne ""){
           
            my $seq_obj_0 = Bio::Seq->new(-seq => $sec_final,
                       -display_id => $rf,
                       -alphabet => "protein",
                           );

          $seqio_obj_Out->write_seq($seq_obj_0);
        
           my $red = "" ;        
          
  	     $red =  $Redun_red{$rf};

                if((scalar @new_seq_red) > 0){

                  if($red eq "NA"){
		      $red = join(",", @new_seq_red);
		         }
                   else{
                       $red .=",".join(",", @new_seq_red);
		           }
		          }

               my $ent = "" ;              

                 if(@ent_seq){ 
                     $ent =join(",", @ent_seq );                          
	                 }

	    $Redun_red{$rf} = $red ;
	    $Redun_rep{$rf} = $ent ;
	 
	         }
             }          
 

    my @keys_red = keys %Redun_red  ;


      while(my $ky_rf = shift @keys_red){
     
	  my $red =  $Redun_red{$ky_rf} ;
          my $ent =  $Redun_rep{$ky_rf} ;

        print $nr  $ky_rf,"\t",$ent,"\t",$red,"\n" ;

             }


   close $nr ;
}

  sub Extension {

   my ( $rf ,$querys, $seqs, $seq_product, $new_red, $ent ) = @_; 

     my ($id_qr, $pos_in_qr, $pos_fn_qr, $lon_target ,$pos_in_tg, $pos_fn_tg, $sz_blocks, $pos_blocks_query, $pos_blocks_target) = split(/\t/, $rf) ;

    my $seq = $$seqs{$id_qr} ;
    my @lon = split(//, $seq) ;
    my $lon = scalar @lon  ;  


 if(@$querys){
  
     my $ln = shift @$querys ;

    my ($id_qr_ac, $pos_in_qr_ac, $pos_fn_qr_ac, $lon_target_ac ,$pos_in_tg_ac, $pos_fn_tg_ac, $sz_blocks_ac, $pos_blocks_query_ac, $pos_blocks_target_ac) = split(/\t/, $ln) ;  
   

          $pos_in_qr_ac -= 1;
          $pos_fn_qr_ac -= 1 ;

        my $seq_ac = $$seqs{$id_qr_ac} ;
        my @lon_ac = split(//, $seq_ac) ;
        my $lon_ac = scalar @lon_ac  ;

   
     if( $pos_in_tg_ac > $pos_fn_tg ){

	    my $subseq = "" ;
	    my $size =  ( $pos_fn_qr  -  $pos_in_qr ) + 1 ;
	    $subseq = substr($seq, $pos_in_qr, $size) ;
	            
	              
	    if( $subseq ne ""){

 		 my $dif = $pos_in_tg_ac - $pos_fn_tg ;
		 my $NN  = "X" x $dif ;
		 $seq_product .=$subseq.$NN ;
                  push(@$ent, $id_qr );  
                   
	           }
           else{
	       push(@$new_red, $id_qr );
	       }
	           
	    $pos_in_tg = $pos_in_tg_ac ;
	    $pos_fn_tg = $pos_fn_tg_ac  ;
	    $pos_in_qr = $pos_in_qr_ac ;
	    $pos_fn_qr = $pos_fn_qr_ac ;
                             
            }

     else{
     

	    if( $pos_fn_tg  == $pos_in_tg_ac ){

                my $subseq = "" ;
                my $size = ($pos_fn_qr - $pos_in_qr ) + 1  ;
		$subseq = substr($seq, $pos_in_qr, $size) ;
		            
            
		if( $subseq  ne ""){

		    $seq_product .= $subseq ;         
		    push(@$ent, $id_qr );

	         	} 
                    else{
                  push(@$new_red, $id_qr );
                      }       


		$pos_in_tg = $pos_in_tg_ac ;
		$pos_fn_tg = $pos_fn_tg_ac  ;
		$pos_in_qr =  1  ;
                $pos_fn_qr = $pos_fn_qr_ac ;
     
	                   }

         elsif($pos_fn_tg  > $pos_in_tg_ac  ){           
     
		my  $pos_cut_ac = 0  ;
		my  $pos_cut = 0  ;  
		my  $pos_sh = 0 ;


  
my $positions = &Last_Common_Block($pos_blocks_target_ac, $pos_blocks_target, $pos_blocks_query_ac, $pos_blocks_query , $sz_blocks_ac, $sz_blocks ) ;

 ($pos_sh, $pos_cut_ac, $pos_cut ) = split(/_/, $positions) ;


         
       

		my $subseq  = "" ; 
 
		if( $pos_sh != 0  ){

		     $pos_fn_qr = $pos_cut ;
		     my $size = ($pos_fn_qr - $pos_in_qr )+1 ;
          	     $subseq = substr($seq, $pos_in_qr , $size) ;


		     $pos_in_qr  =  $pos_cut_ac  ;
		     $pos_in_tg  = $pos_sh  ;
  
		    }
		else{

		    my $size = ($pos_fn_qr - $pos_in_qr )+1 ;
              	    $subseq = substr($seq, $pos_in_qr , $size) ;
                      

		    $pos_in_tg  = $pos_in_tg_ac ;
		    $pos_in_qr  = $pos_in_qr_ac  ;
     
              		}           
		
		if($subseq ne ""){    
                   $seq_product .= $subseq ;    
		   push(@$ent, $id_qr );
        	          }
                   else{
                  push(@$new_red, $id_qr );
                      }        
          


		$pos_fn_tg =  $pos_fn_tg_ac ;
                $pos_fn_qr = $pos_fn_qr_ac ;
         
	    }
	}

	$seq = $seq_ac ;
	$id_qr = $id_qr_ac ;
	$lon = $lon_ac ;
  $pos_blocks_query = $pos_blocks_query_ac ;
  $pos_blocks_target = $pos_blocks_target_ac ;
  $sz_blocks =  $sz_blocks_ac ;


    my $rf = join("\t", $id_qr, $pos_in_qr, $pos_fn_qr, $lon_target ,$pos_in_tg, $pos_fn_tg, $sz_blocks, $pos_blocks_query, $pos_blocks_target)  ;

  Extension($rf ,$querys, $seqs, $seq_product, $new_red, $ent);

          }



 else{



    my $size =  ( $lon - $pos_in_qr ) ;
    my $subseq  = "" ;

    $subseq = substr($seq, $pos_in_qr , $size) ;

    if( $subseq ne ""){
	$seq_product .= $subseq ;
	push(@$ent, $id_qr );
          }
         else{
       push(@$new_red, $id_qr );
	    }

    return $seq_product ; 
     }
   }



  sub Last_Common_Block { 

 
  my  ( $Bact_target , $Bref_target, $Bact, $Bref, $size_act , $size_ref  ) =  @_ ;

  my %Mat_Ref  ;
  my %Mat_Act ;


     my @Bact_target  = split(/,/, $Bact_target) ; 
     my @Bref_target  = split(/,/, $Bref_target) ;  
     my @Bact  = split(/,/, $Bact) ;
     my @Bref  = split(/,/, $Bref) ;
     my @size_ref = split(/,/, $size_ref) ;
     my @size_act = split(/,/, $size_act) ;



        while(@Bact_target){  

	    my $pos_act_target_in  = shift @Bact_target ;
            my $pos_act_target_fn = 0;          
            my $pos_act_in  = 0;
            my $size = shift @size_act  ;

	        if($size == 1){

		     $pos_act_in  = shift @Bact ;
		     $Mat_Act{$pos_act_target_in} = $pos_act_in ;

                      }           
		 else{
            
              $pos_act_target_fn = $pos_act_target_in + $size ;
              $pos_act_in  = shift @Bact   ;           
          
    for(my $i = $pos_act_target_in ; $i < ( $pos_act_target_fn +1) ; $i+=1){

		  	    $Mat_Act{$i}  = $pos_act_in ;
			    $pos_act_in += 1 ;

				     }
				   }
                              }


 
        while(@Bref_target){      


	    my $pos_ref_target_in  = shift @Bref_target ;
            my $pos_ref_target_fn = 0;
	    my $pos_ref_in = 0 ;
	    my $size = shift @size_ref  ;


	        if($size == 1){
		       
                        $pos_ref_in  = shift @Bref   ; 
         		$Mat_Ref{$pos_ref_target_in}  = $pos_ref_in ;
 			       
                        }

            else{
           
              $pos_ref_target_fn = $pos_ref_target_in + $size ;
              $pos_ref_in  = shift @Bref ;
           
  for(my $i = $pos_ref_target_in ; $i < ( $pos_ref_target_fn +1) ; $i+=1){

                $Mat_Ref{$i}  = $pos_ref_in ;
        	$pos_ref_in += 1 ;

                   }
                 } 
     }


  my  @keys_Act = sort { $a <=> $b} (keys %Mat_Act) ;
  my  @keys_Ref = sort { $a <=> $b } (keys %Mat_Ref) ;

  my  $Big_Common = 0 ;


     $Big_Common = big(\@keys_Act ,\@keys_Ref ) ;


  my  $Posicion_In_Ct_Act = -10;
     
  if(exists $Mat_Act{$Big_Common} ){
     $Posicion_In_Ct_Act = $Mat_Act{$Big_Common} ;  
            }

    my  $Posicion_Fn_Ct_Ref =  -10;

  if(exists $Mat_Act{$Big_Common} ){
    $Posicion_Fn_Ct_Ref = $Mat_Ref{$Big_Common} ;
    $Posicion_Fn_Ct_Ref -= 1 ;
          }

    my $Com = $Big_Common."_".$Posicion_In_Ct_Act."_".$Posicion_Fn_Ct_Ref  ;
    return $Com  ;

     }


 sub big  {

    my $l1 = shift @_ ;
    my $l2  = shift @_ ; 
    my $big = 0;
    my  %L2  = map { $_ => ""} @$l1 ;

    while(@$l2){

	my $ch2 = shift @$l2 ;

	if((exists $L2{$ch2}) and ($ch2 > $big)) {
	    $big = $ch2 ;
             }
           }
     return $big ;
    
     }
