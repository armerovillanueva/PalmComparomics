#!/usr/bin/env perl                                                                                                                                                                   
use strict;
use warnings;
use Getopt::Long qw(GetOptions);
use Bio::Seq;
use Bio::SeqIO;
use Bio::Perl;

# Aim: parsing psl file
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28 




my $psl_file = "" ;
my $dispersion = "" ;
my $output = "" ;


     GetOptions (
         'p=s' => \$psl_file,
         'd=s' => \$dispersion,
         'o=s' => \$output,
    )  or die "Usage:$0 -p psl_file -d dispersion -o output_file\n" ;

 main :{

     if((-s $psl_file) and (-f $output)){

	 Parsing_Blat($psl_file, $dispersion, $output);

          }
     else{
	 die "Usage:$0 Non Files\n" ;
         }
      }


#Determine whether the dispersion of the alignment blocks for the same query is less than a given parameter (initialized to 100000)

 sub Dispersion {

### Size blocks, posicion in target, dispersion user

    my ($Sb , $Pt, $Ref) = @_;
   
    my $con_disp = 0 ;
    my $disp_mean = 0 ;
 
    my @sz_blocks = split(/,/, $Sb );
    my @pos_tg = split(/,/, $Pt);
    my $qtt_blocks = scalar @sz_blocks ;

    if(@pos_tg){

	my $pos_ref = shift @pos_tg  ;

        while(@pos_tg){
       
	    my $pos_act = shift  @pos_tg ;
            my $sz_bq = shift @sz_blocks ;          
	    $con_disp += ($pos_act  - ($pos_ref+$sz_bq));
	    my $val= ($pos_act  - ($pos_ref+$sz_bq)) ;
              $pos_ref = $pos_act ;  

	        }
       	$disp_mean = $con_disp/$qtt_blocks;
            }


    if($disp_mean < $Ref){
	return 1 ;
         }
    else{ 
	return 0 ;
       }
    }

  sub Parsing_Blat  {

## psl file,reference dispersion, hash length target  
    my  ($psl, $dis_ref, $Op)  = @_ ;

    unless( $dis_ref =~ m/[0-9]+/){
	die "The dispersion must be a integer \n" ;    
             }

    open(my $fl , '<', $psl ) or die "Can't read file $psl" ;      
    open(my $op , '>', $Op ) or die "Can't read file $Op" ;

    my %Target ;

      while(my $ln = <$fl>){
   
	  chomp($ln);
       
	  my @ar = split(/\t/, $ln);
          my $match = $ar[0] ;           
	  my $id_qr = $ar[9] ;
	  my $pos_inc_qr = $ar[11] ;
	  my $pos_fn_qr = $ar[12] ;       
	  my $id_target= $ar[13] ;
	  my $lon_target = $ar[14] ;
	  my $pos_inc_tg = $ar[15] ;
	  my $pos_fn_tg = $ar[16] ;  
	  my $sz_blocks = $ar[18] ;         
	  my $pos_blocks_query = $ar[19];
	  my $pos_blocks_target = $ar[20];

      ### Calculation of a relationship between identity and coverage

	  my $total_cov = 0;
          my @blocks  = split(/,/, $sz_blocks);
          my $incov = sprintf("%.2f",  $match/$lon_target); 
        
      ###
	  my $ind = &Dispersion($sz_blocks, $pos_blocks_target, $dis_ref);
       
   
          if($ind == 1){
       
my $str = join("\t", $id_qr, $pos_inc_qr, $pos_fn_qr, $lon_target ,$pos_inc_tg, $pos_fn_tg, $sz_blocks, $pos_blocks_query, $pos_blocks_target, $incov  );
                
          $Target{$id_target}{$str} ="" ; 
      	  
              }
             }
    
    my @targets = keys %Target ;

   while(my $tg = shift @targets){
       my @str  = keys %{$Target{$tg}} ;
         while(my $str = shift @str){         
        print $op  $tg,"\t",$str,"\n" ;  
	        }
           }

     close($op);
          }
