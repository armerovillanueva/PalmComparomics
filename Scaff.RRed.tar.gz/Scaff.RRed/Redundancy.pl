#!/usr/bin/env perl

use strict;
use warnings;
use Getopt::Long qw(GetOptions);
use Bio::Seq;
use Bio::SeqIO;
use Bio::Perl;
no warnings 'recursion';


# Aim: Identify redundant sequences 
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28   


my $input = "" ;
my $output = "" ;

     GetOptions (
         'i=s' => \$input,
         'o=s'  => \$output,
    )  or die "Usage:$0 -i input_file -o output_file\n" ;

 main :{

     if((-s $input ) and (-f $output) ){
         
	 Parsing($input, $output);
	  
          }
     else{
	 die "Usage:$0 Non Files\n" ;
         }
      }


 sub  Parsing {

    my ($input, $output) = @_ ;

    open(my $in , '<', $input ) or die "Can't read file $input" ;
    open(my $op , '>', $output ) or die "Can't read file $output" ;

    my %Reference  ;


## Input : target_seq query_seq pos_int_alg_qr pos_fn_alig_qr Length_target pos_int_alg_tg pos_fn_alig_tg size_blocks blocks_pos_qr blocks_pos_tg identity/target_length 

 
     while(my $ln = <$in>){
          
          chomp($ln);
   
           my @ar = split(/\t/, $ln);
	   my $rf = $ar[0] ;
           my @cb = split(/,/, $ar[7]);  

## Quantity blocks

           my $cb = scalar  @cb ;

###   Query  and the alignment positions in the target

           my $str = $ar[1]."§".$ar[5]."§".$ar[6]."§".$cb."§".$ar[10] ;

### Recovering all queries for each target

           $Reference{$rf}{$str} = "";   

           }

    my @Ref = keys %Reference ;

       while(@Ref){

	   my $rf = shift @Ref ;
           my @targets = keys %{$Reference{$rf}} ;
           Redundant($rf,\@targets, $op);

            }
         }


 sub Redundant   {

## protein reference ,data target(s), redundant file, non redundant file

     my ($rf, $in, $op) = @_ ; 

     my %red ;
     my %non_red ;       
     my $ref = "" ;
     my $out = $rf ;
     my $inter = 0 ;

         my @mat = @$in ;
         my @Cp = @$in ; 
          $ref = shift @$in ;    
  


   if(@$in){

### Identification redundant sequences

     RedNon($ref, \@$in, \%red, \%non_red, \@mat, \@Cp);

 
      my @rds = keys %red;
      my @nrds = keys %non_red  ;
      
       if(@nrds){
   
       my $nr_str = join(",", @nrds);

          $inter = intersection($nr_str); 

          $out .="\t$nr_str" ;                                                           

             }
       else{
	   die "Error It is not possible to identify sequence\n" ;
           }   

     if(@rds){
      $out.="\t".join(",", @rds)."\t" ;  
          }
     else{
         $out.="\tNA\t";
         }  
        }  
### a single transcript

     else{
        $out .="\t$ref\tNA\t" ; 
         }

     $out .=$inter."\n" ;

     print $op $out;

      }


#Use two matrices, one of which extracts the query sequence under analysis and the other is used to determine the redundancy or not of the sequence under analysis of the first matrix

# A sequence is redundant if it has a lower coverage (size blocks) of the target sequence compared to the sequence under analysis of the first matrix


  sub RedNon{

    my ($ref, $input, $red, $non_red, $mat, $cp) = @_; 

### Control
        
      if((@$input) and (@$mat)){

	  my $act = shift @$mat; 
	  my $ind = 0;

         $ind = &cmp($ref, $act);       

# The sequence under analysis is declared redundant
	      
    if($ind == 1){
      
	  $$red{$ref} = "" ;
  	  my @new_input ;

       
            while(@$input){
	       my $od_ip = shift  @$input ;
              if($od_ip ne $ref){
		  push(@new_input,$od_ip);
	          }
	        }
      
           my $new_ref = shift @new_input ;  
	     @$mat = @$cp;
          RedNon($new_ref, \@new_input, $red, $non_red, $mat, $cp);          

            }

# The sequence of the second matrix is declared redundant

     elsif($ind == 2 ){

          $$red{$act} = "" ;     
	  my @new_input ;

	  while(@$input){
            my $od_ip = shift  @$input ;
              if($od_ip ne $act){
		  push(@new_input , $od_ip);
                }
           }     

	  RedNon($ref,\@new_input, $red, $non_red, $mat, $cp);

            }

##  
    elsif($ind == 0){

	RedNon($ref, $input, $red, $non_red, $mat, $cp);

           }
###  end input and mat 
      }

### if non input  and mat

     elsif((!@$input) and (@$mat)){ 

            my $act = shift @$mat;
            my $ind = 0 ;
            $ind = &cmp($ref, $act);        


       if($ind == 1){
       
        $$red{$ref} = "" ;
        return ;
         
             }

    elsif($ind == 2){

	 $$red{$act} = "" ;
         RedNon($ref, $input, $red, $non_red, $mat, $cp);  

            }
    
     elsif($ind == 0){
	 RedNon($ref, $input, $red, $non_red, $mat, $cp);
            }
        }

#### if input and not mat

    elsif((@$input) and (!@$mat)){
   
          $$non_red{$ref} = "" ;

	my @new_input ;

          while(@$input){
	      my $od_ip = shift  @$input ;
              if($od_ip ne $ref){
		  push(@new_input, $od_ip) ;
	          }
               }        

          my $new_ref = shift @new_input ;
          @$mat = @$cp;
          RedNon($new_ref,\@new_input, $red, $non_red, $mat, $cp);	
   
          }

### if non input and non mat

    elsif((!@$input) and (!@$mat)){

         $$non_red{$ref} = "" ;        
	 return ;
        }
    }


 sub cmp {

     my ($ref, $next) = @_;

     my ($id_ref, $pos_in_ref, $pos_fn_ref, $sz_bq_ref, $incov_ref) = split(/§/, $ref);
     my ($id_act, $pos_in_act, $pos_fn_act, $sz_bq_act, $incov_act) = split(/§/, $next);


if(  ($id_ref ne $id_act) and ($pos_in_ref > $pos_in_act) and ($pos_fn_ref < $pos_fn_act ) ){
       return 1;
          }
elsif(  ($id_ref ne $id_act) and ($pos_in_ref == $pos_in_act) and ($pos_fn_ref < $pos_fn_act ) ){
    return 1;
    }
elsif(  ($id_ref ne $id_act) and ($pos_in_ref > $pos_in_act) and ($pos_fn_ref == $pos_fn_act ) ){
    return 1;
    }

#If the sequences have the same alignment positions to the target sequence, the query sequence that has the least coverage of the target sequence (block size) is declared redundant

elsif( ($id_ref ne $id_act) and ($pos_in_ref == $pos_in_act) and ($pos_fn_ref == $pos_fn_act )){

       if( $incov_ref < $incov_act ){
          return 1 ;
            }
        else{ 
	  return 2 ;
	 }
     }
 else{
    return 0; 
    }
   }



sub intersection {

    my  $st = shift  @_  ;
    my  @ar = split(/,/, $st);
    my  @pre  = map { my @ar = split(/§/, $_) ;  [ $ar[0], $ar[1], $ar[2], $ar[3] ] }  @ar ;
    my  @ord = sort { $a -> [1] <=> $b -> [1] } @pre ;  
    my  $first = shift @ord ; 
    my  $pos_fn_ref  =  $first -> [2] ;
    my  $ind = 0 ; 
        

    while((@ord) and ($ind != 1)){


       my $ln = shift @ord ;
       my $pos_in_act  =  $ln -> [1] ;
       my $pos_fn_act  =  $ln -> [2] ;

       if( $pos_fn_ref >= $pos_in_act  ){
           $ind = 1 ;
       }
      else{
          $pos_fn_ref  = $pos_fn_act ; 
           }
        }
return $ind ; 
  }
