#!/usr/bin/env perl                                                                         
use strict;
use warnings;
use Getopt::Long qw(GetOptions);

# Aim: Choose the best alignment for each polypeptide 
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28  


my $cip_calp = "" ;
my $identity = "" ;
my $coverage = "" ;
my $output  = "" ;
my $cover_inf_40 = "" ;

  GetOptions (
         'c=s' => \$cip_calp,
         'i=s' => \$identity,
         'q=s' => \$coverage,
         'r=s' => \$cover_inf_40,
         'o=s' => \$output,
       )  or die "Usage:$0 -c File -i identity -q coverage_>40 -r coverage_<40 -o output_file\n" ;

main:{

    if((  -s $cip_calp )  and ( $output )) {

   
	open(my $lf , '>', $output ) or die "Can't read file $output" ;
	open(my $fl , '<', $cip_calp ) or die "Can't read file $cip_calp" ;
     
	if((($identity >= 0.0 ) and ( $identity <= 1)) and (($coverage >= 0.0 ) and ( $coverage <= 1))  and (($cover_inf_40 >= 0.0 ) and ( $cover_inf_40 <= 1) )){

	      
	    my %mat ;


	    while(my $ln = <$fl>){

		chomp($ln);
		my ($qr, $tg, $cip, $calp, $calp_tg, $signo )  = split(/\t/, $ln);
          
		if( exists $mat{$qr}{$tg} ){
		    $mat{$qr}{$tg} .="§".$cip."\t".$calp."\t".$calp_tg."\t".$signo ;
		}
		else{    
		    $mat{$qr}{$tg} =$cip."\t".$calp."\t".$calp_tg."\t".$signo ;
		}
	    }


	    my %same_strand ;
	    my @keys = keys %mat ;

  

	    while(@keys){

		my $qr = shift @keys ; 
		my $cip_mean = 0;

   
		foreach my $tg (keys %{$mat{$qr}}){  



		    my @data_hsp = split(/§/, $mat{$qr}{$tg});
		    my $fr_hsp =  shift @data_hsp ;
		    my ( $cip_ref, $calp_qr_ref, $calp_tg_ref, $strand_ref ) = split(/\t/, $fr_hsp ) ;
		    my $ind = 0 ; 
      

		    while((@data_hsp) and ( $ind != 1)){    

			my $in_hsp = shift @data_hsp ;
			my  ( $cip_act, $calp_qr_act, $calp_tg_act, $strand_act ) = split(/\t/, $in_hsp ) ;
          
			if($strand_act ne $strand_ref){ 
			    $ind = 1 ;
			}
			else{
			    $cip_ref = ($cip_ref+$cip_act)/2 ;
			    $calp_qr_ref += $calp_qr_act ;
			    $calp_tg_ref += $calp_tg_act ;      
			}

		    }

		    if($ind == 0){

			$same_strand{$qr}{$tg}= $cip_ref."\t".$calp_qr_ref."\t".$calp_tg_ref."\t".$strand_ref ;
		    }
		}
	    }

	    my  @keys_st = keys  %same_strand ;

	    while(@keys_st){

		my $query = shift @keys_st ;
		my @targets = keys %{$same_strand{$query}} ;  
		my @Ord ;

		while(@targets){
		    my $tg = shift @targets ; 
		    my @str = split(/\t/, $same_strand{$query}{$tg}) ;   
         
    
if (( ( $str[0]  >= $identity ) and ( $str[1]  >=  $cover_inf_40  )  and ( $str[2] <= 0.4 )) or
    ( ( $str[0]  >= $identity ) and ( $str[1]  >= $coverage )  and ( $str[2] > 0.4 ) ) ){
    push(@Ord, [ $tg, $str[0], $str[1], $str[2], $str[3] ]);
}
		}

  
	 if(@Ord){ 

		    my @ord_idt =  sort { $b -> [1] <=> $a -> [1] || $b -> [2] <=> $a -> [2]  || $b -> [3] <=> $a -> [3] } @Ord ; 
		    my @ord_cov = sort { $b ->  [2] <=> $a -> [2] || $b ->  [1] <=> $a -> [1] ||  $b ->  [3] <=> $a -> [3]   } @Ord ;


		    my $best_idt = shift @ord_idt ;                                                               
		    my $best_cov = shift @ord_cov ;                                                               
		    my $best = "" ;   

		    if( ((($best_idt -> [1]) - ($best_cov -> [1]) ) > 0.07 ) and ( (($best_cov -> [2]) - ($best_idt -> [2])  )  < 0.12)){
			$best = $best_idt ;                                                                                      }         
		    else{                        
			$best = $best_cov  ;                                                                               }   

		    print $lf $query,"\t",$best->[0],"\t",$best->[1],"\t",$best->[2],"\t",$best->[3],"\t",$best->[4],"\n" ;

		}
	    }

	    close($lf);
 
	}
	else{
	    die "Valid values for identity and coverage between 0 and 1\n"  ;
	}
    }
    else{
	die "Non Files\n" ;
    }
}
