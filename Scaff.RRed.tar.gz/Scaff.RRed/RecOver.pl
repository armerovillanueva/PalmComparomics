#!/usr/bin/env perl                                                                                                                                                                     
use strict;
use warnings;
use Getopt::Long qw(GetOptions);


# Aim: separing overlapping polypeptides from the other
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28  




my $redcy = "" ;
my $stepI = "";
my $output_mn = "" ;
my $output_one = "" ;
my $new_red = "" ;

GetOptions (
         'i=s' => \$redcy,
         's=s'  => \$stepI,
         'o=s' => \$output_mn, 
         'g=s' => \$output_one,
         'n=s' => \$new_red,
    )  or die "Usage:$0 -i redundancy_input  -s result_file -o output_to_many -g output_to_one -n redundancy_output\n" ;


  main :{

    if(  (-s $redcy) and (-s $stepI) and ( -f $output_mn ) and ( -f $output_one) and ( -f $new_red)){
	parsing($redcy, $stepI, $output_mn, $output_one, $new_red);
        }
    else{
	die "Usage:$0 Non Files\n" ;
         }
       }


 sub  parsing  {

     my ($red, $step, $outmn, $outone, $nred) = @_ ;

   my %mat ;

     open(my $rd , '<', $red ) or die "Can't read file $red" ;
     open(my $st , '<', $step ) or die "Can't read file $step" ;
     open(my $om , '>', $outmn ) or die "Can't read file $outmn" ;
     open(my $oo , '>', $outone ) or die "Can't read file $outone" ;
     open(my $nm , '>', $nred ) or die "Can't read file $nred" ; 


      while(my $ln = <$st>){   
        
          chomp($ln);
          my @ar = split(/\t/, $ln);  
          $mat{$ar[1]} = $ln ;

               }

       

      while(my $ln = <$rd>){

	  chomp($ln);
         
          my @ar = split(/\t/, $ln);
          my @red = split(/,/, $ar[1]);
	  my @rep = split(/,/, $ar[2]);
          my @new_red = map {  my @arI = split(/§/, $_); $arI[0] } @red ;
	  my @new_rep = map {  my @arI = split(/§/, $_); $arI[0] } @rep ;
                   
  
 print $nm $ar[0],"\t",join(",", @new_red),"\t",join(",", @new_rep),"\n" ;


     if((scalar @red) > 1){ 

           while(my $rd = shift @red){             
               
	 	  my @inf_rd = split(/§/, $rd );
                      
               my $ln_mn  = $mat{$inf_rd[0]} ; 
		 print $om $ln_mn,"\n" ;
      
	            }
	          }

             else{
                 
		 my @inf_rd = split(/§/, $ar[1] );
		 my $ln_one = $mat{$inf_rd[0]} ;
		 print $oo $ln_one,"\n" ;

             }
          }
    }
