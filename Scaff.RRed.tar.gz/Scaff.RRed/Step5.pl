#!/usr/bin/env perl                                                                                                                                                                   
use strict;
use warnings;
use Getopt::Long qw(GetOptions);
use File::Temp qw(tempfile);
use Bio::Seq;
use Bio::SeqIO;
use Bio::Perl;


# Aim: scripts last step (scaffolding).
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28 




my $SEE = 0;
my $message = 0  ;
my $psl_file = "" ;
my $frame = "" ;
my $dispersion = "" ;
my $output = "" ;


     GetOptions (
         'p=s' => \$psl_file,
         'f=s' => \$frame,
         'd=s' => \$dispersion,
         'o=s' => \$output,
    )  or die "Usage:$0 -p psl_file -f frame -d dispersion   -o output_file\n" ;

 main :{

     if((-f $psl_file) and  (-f $frame ) ){

	 my ($tm, $tmp) = tempfile();
	  $tm->flush ;
         ## many
          my ($mn, $tmp_mn) = tempfile();            
         $mn->flush ;

         ## one

         my ($on, $tmp_on) = tempfile();  
	 $on->flush ;

         ## output redundancy Redunndancy.pl
         
	 my ($ed, $tmp_red) = tempfile();
         $ed->flush ;

         ## output redundancy RecOver

	 my ($rd, $tmp_rd) = tempfile();
         $rd->flush ;
        
        my $output_redundancy =  $output.".table" ;
        my $output_fasta =  $output.".fasta" ;          
 

###   

&process_cmd("./Step.5.I.pl -p $psl_file -d $dispersion -o $tmp");
  
&process_cmd("./Redundancy.pl -i $tmp -o $tmp_red");
 
&process_cmd("./RecOver.pl -i $tmp_red -s $tmp -o $tmp_mn -g $tmp_on  -n $tmp_rd");
 
   close($tm);
   close($ed);

 &process_cmd("./Extension.pl -i $tmp_mn  -s $frame  -o $output_fasta -r $tmp_rd  -n $output_redundancy");

   close($mn);
   close($rd);     

 &process_cmd("./Fasta.pl -o  $tmp_on  -f $frame -m $output_fasta");

          }
     else{
	 print "Non file $psl_file $frame\n" ;

         }
      }


 sub process_cmd {

 
     my ($cmd) = @_;
     print STDERR "CMD: $cmd\n" unless ($message);

     my $start_time = time();
     my $ret = system("bash", "-c", $cmd);
     my $end_time = time();

    if ($ret) {
        die "Error, cmd: $cmd died with ret $ret";
         }

     print STDERR "CMD finished (" . ($end_time - $start_time) . " seconds)\n" if $SEE;
     return;

       }
