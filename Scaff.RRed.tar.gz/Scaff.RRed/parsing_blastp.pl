#!/usr/bin/env perl                                                                          
use strict;
use warnings;
use XML::Twig;
use Data::Dumper;
use Getopt::Long qw(GetOptions);

# Aim: make a psl file and parameters alignment file of blast output
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28                                                                                




sub Identical {

    my $seq_qr = shift @_ ;
    my $seq_tg =shift @_ ;
    my $pos_qr = shift @_ ;
    my $pos_tg = shift @_ ;
    my $pos_in_qr = shift @_ ;
    my $pos_in_tg = shift @_ ;
    my $sizes = shift @_ ;
    my $pos_ct_qr = $pos_qr ;
    my $pos_ct_tg = $pos_tg ;
    my $pos_rf_qr = 0 ;
    my $pos_rf_tg = 0 ;
    my $ind = 0;

    while(@$seq_qr){

	my $nc_qr = shift @$seq_qr ;
	my $nc_tg = shift @$seq_tg ;

	if(($nc_qr eq  $nc_tg) and ($ind == 0)){
	    $pos_rf_qr = $pos_ct_qr ;
	    $pos_rf_tg = $pos_ct_tg ;
	    $ind = 1;
	}
	elsif(($nc_qr ne  $nc_tg) and ($ind == 0)){}
	elsif( ($nc_qr eq $nc_tg ) and ($ind == 1 )){}
	elsif(($nc_qr ne $nc_tg ) and ($ind == 1)){
	    my $size = $pos_ct_qr - $pos_rf_qr ;
	    push(@$pos_in_qr, $pos_rf_qr);
            push(@$pos_in_tg, $pos_rf_tg);

	    if($size != 1){
		$size -= 1 ;
	    } 

	    push(@$sizes, $size) ; 
	    $ind = 0;
	}

        if($nc_qr ne "-"){
	    $pos_ct_qr += 1 ;
	}

	if($nc_tg ne "-"){
            $pos_ct_tg += 1 ;
	}
    }

    if($ind == 1){
        my $size = $pos_ct_qr - $pos_rf_qr ;
 
	if($size != 1){
	    $size -= 1 ;
	}  

	push(@$pos_in_qr, $pos_rf_qr);
	push(@$pos_in_tg, $pos_rf_tg);
	push(@$sizes, $size) ;
    }
}


 
 sub  Best_HSP {

    my $lista = shift @_ ;
    my @mat = split(/%/, $lista) ;
    my @mat_pre = map { my @ar1=  split(/\t/, $_ ) ; [ $ar1[0], $ar1[1], $ar1[2], $ar1[3], $ar1[4], $ar1[5] ,  $ar1[6], $ar1[7], $ar1[8], $ar1[9], $ar1[10], $ar1[11] ] } @mat ;
    my @mat_ord = sort { $b -> [4] <=> $a -> [4] || $b -> [7] <=> $a -> [7] } @mat_pre ;
    my $best = shift @mat_ord ;
    my $best_string = join("\t", @{$best});
    return $best_string ;
   }


sub Regiones {

    my $mat = shift @_ ;
    my $Pos_Inc = shift @_ ;
    my $Pos_Fn = shift @_ ;
    my $str = shift @_ ;  
    my $Resultados = shift @_ ;
    my $cd_pos_inc  = shift @_ ;
    my $cd_pos_fn  = shift @_ ;           



   if(@$mat){  


	my $hsp = shift @$mat ;
	my $pos_inc_hsp = $hsp -> [$cd_pos_inc] ;
	my $pos_fn_hsp = $hsp -> [$cd_pos_fn] ;

  
	if( ($pos_inc_hsp  >= $Pos_Inc) and ($pos_fn_hsp <= $Pos_Fn)   ){

            my $hsp_str  = join("\t",@{$hsp});
	    $str.="%".$hsp_str;
	    Regiones($mat, $Pos_Inc, $Pos_Fn, $str, $Resultados,  $cd_pos_inc, $cd_pos_fn) ;

	       }

  elsif( ($pos_inc_hsp  >= $Pos_Inc) and ($pos_fn_hsp > $Pos_Fn) and ( $pos_inc_hsp <= $Pos_Fn  )  and (  $pos_inc_hsp < ( $Pos_Fn -  4 )) ){

	    my $hsp_str  = join("\t", @{$hsp});
	    $str.="%".$hsp_str;         
            $Pos_Fn = $pos_fn_hsp ;
	    $Pos_Inc = $pos_inc_hsp ;

    Regiones($mat,  $Pos_Inc, $Pos_Fn, $str, $Resultados,  $cd_pos_inc, $cd_pos_fn) ;

           }
        elsif(($pos_inc_hsp  >= $Pos_Inc) and ($pos_fn_hsp > $Pos_Fn ) and (  $pos_inc_hsp <= $Pos_Fn  ) and (  $pos_inc_hsp > ( $Pos_Fn  -5 )) ){   
	    push(@$Resultados, $str) ;
            my $hsp_str  = join("\t", @{$hsp});
	    Regiones($mat, $pos_inc_hsp, $pos_fn_hsp, $hsp_str, $Resultados,  $cd_pos_inc, $cd_pos_fn) ;
              }
	else{
            push(@$Resultados, $str) ;
	    my $hsp_str  = join("\t", @{$hsp});
            Regiones($mat, $pos_inc_hsp, $pos_fn_hsp, $hsp_str, $Resultados,  $cd_pos_inc, $cd_pos_fn) ;
          }
         }
   else{
	push(@$Resultados, $str) ;
	return 0 ;
    }
}

 sub  HSP {

     my $hsp = shift @_ ;
     my $query_name  = shift @_ ;
     my $query_length =  shift @_ ;
     my $hit_name  =  shift @_ ;
     my $hit_length = shift @_ ;
     my $Resultados  = shift @_ ;
     my @HSPs_Final = () ;
     my @HSPs_ORD  = () ;
     my $str1 = "" ;
     my $str2 = "" ; 


        @HSPs_ORD  = sort { $a -> [0]  <=>  $b -> [0]  }  @$hsp ;

      if( (scalar @HSPs_ORD ) > 1) {


	  my $first_hsp = shift @HSPs_ORD ;
	  my $pos_inc = $first_hsp->[0] ;
	  my $pos_fn = $first_hsp->[1] ;
	  my $first_str = join("\t",  @{$first_hsp});
	  my @HSP_UNIQUES_QUERY = () ;
  
  Regiones(\@HSPs_ORD, $pos_inc, $pos_fn, $first_str , \@HSP_UNIQUES_QUERY, 0, 1) ;

	 
	  my @Best_HSP = () ;

      while(@HSP_UNIQUES_QUERY){
         
          my $line = shift @HSP_UNIQUES_QUERY ;
	  my @ar_exon = split(/%/, $line) ;
    

        if((scalar  @ar_exon) > 1){

          my $best_hsp = Best_HSP($line);       
	  push(@Best_HSP, $best_hsp);
            
                         }
                   else{
                       push(@Best_HSP, $line);      
                   }
                 }

  
 if((scalar @Best_HSP) > 1 ){
    
my @Best = map { my @Ar = split(/\t/, $_) ; [ $Ar[0], $Ar[1], $Ar[2], $Ar[3], $Ar[4], $Ar[5], $Ar[6], $Ar[7], $Ar[8], $Ar[9]  , $Ar[10], $Ar[11] ] }  @Best_HSP ;

      my @HSPs_Best = sort { $a -> [2]  <=>  $b -> [2] } @Best ;

  my @HSP_UNIQUES_TARGET = () ;

               my $first_best = shift @HSPs_Best ;
               my $pos_inc_best = $first_best->[2] ;
               my $pos_fn_best = $first_best->[3] ;
               my $first_str = join("\t", @{$first_best});

Regiones(\@HSPs_Best, $pos_inc_best, $pos_fn_best, $first_str , \@HSP_UNIQUES_TARGET, 2, 3) ;

     while(@HSP_UNIQUES_TARGET){

                   my $line = shift @HSP_UNIQUES_TARGET ;
                   my @ar = split(/%/, $line) ;


           if( (scalar @ar)  >  1){

                  my $HSP_Dup_Qr  =  Best_HSP($line);
                     push(@HSPs_Final, $HSP_Dup_Qr);
              
                           }
                   else{
                       push(@HSPs_Final, $line);
              
                                  }
                               }
                  }
       else{
                   push(@HSPs_Final, $Best_HSP[0]);
          
               }
              }
            else{
                   my $hsp = shift @HSPs_ORD ;
                   my $str = join("\t", @{$hsp});
                   push(@HSPs_Final, $str);

               }

       
                       
                    while(@HSPs_Final){

                                    my $string1 = shift @HSPs_Final ;
                                    my @array = split(/\t/, $string1) ;
                                    my $pos_qr = $array[0] ;
                                    my $pos_fn_qr =   $array[1] ;
                                    my $pos_tg = $array[2] ;
                                    my $pos_fn_tg = $array[3] ;
                                    my @seq_qr = split "", $array[9] ;
                                    my @seq_tg = split "", $array[10] ;
				    my $strand = $array[6];
                                    my @pos_inc_query = ();
                                    my @pos_inc_target = ();  
                                    my @sizes = () ;                                    
        
        Identical(\@seq_qr, \@seq_tg, $pos_qr, $pos_tg, \@pos_inc_query, \@pos_inc_target, \@sizes);

                                   my  $hsp_query_cum_length = $array[7] ;
                                   my  $hsp_hit_cum_length  = $array[8] ;
                                   my  $cum_num_identical  =  $array[4] ;
                                   my  $hsp_cum_length = $array[5];
                                   my  $Name_Sp_Target = $array[11];
                                     

                       my $qcov = sprintf('%.2f',($hsp_query_cum_length / $query_length));



                       my $scov = sprintf('%.2f',($hsp_hit_cum_length / $hit_length));

             
                       my $identity = sprintf('%.2f',(($cum_num_identical) /$hsp_cum_length));
                       my $match = $cum_num_identical  ;
                       my $mismatch =  $hsp_cum_length - $cum_num_identical ;
 


     my $str1= $query_name."\t".$hit_name."\t".$identity."\t".$qcov."\t".$scov."\t".$strand."\n" ;
     my $str2 =  $match."\t".$mismatch."\t0\t0\t0\t0\t0\t0\t".$strand."\t".$query_name."\t".$query_length."\t".$pos_qr."\t".$pos_fn_qr."\t".$hit_name."\t".$hit_length."\t".$pos_tg."\t".$pos_fn_tg."\t".scalar @sizes."\t".join(",", @sizes)."\t".join(",", @pos_inc_query)."\t".join(",", @pos_inc_target)."\n" ;

      my $str = $str1."§".$str2 ;  
      
     push(@$Resultados , $str) ;   

			   }
                    }


#### Bagin main

my $blast = "" ;
my $idcov_file = "" ;
my $psl_file = "" ;


  GetOptions (
         'b=s' => \$blast,
         'i=s' => \$idcov_file,
         'p=s' => \$psl_file,
       )  or die "Usage:$0 -b blast_input -i output_idcov -p output_psl \n" ;




   if(( -s $blast )  and ($idcov_file) and ($psl_file)) {

       open(my $ln , '>', $idcov_file ) or die "Can't read file $idcov_file" ;
       open(my $lnI , '>', $psl_file ) or die "Can't read file $psl_file" ; 


    my $twig = XML::Twig->new( twig_handlers =>  {  Iteration => \&Iteration } );
    $twig->parsefile($blast);


   sub Iteration
        {
          my ( $twing, $Iteration ) = @_ ;

	  my $query_name = $Iteration->first_child('Iteration_query-def')->text ;

      if($Iteration->first_child('Iteration_hits')->has_children ){


          my $query_length  = $Iteration->first_child('Iteration_query-len')->text ;      
               
         my @hits = $Iteration->first_child('Iteration_hits')->children('Hit') ;

     while(@hits){

         my $hit = shift @hits ;   
         my $hit_name =  $hit->first_child('Hit_def')->text ; 
         my $hit_length =  $hit->first_child('Hit_len')->text ;
         my @hsp = () ;
         my @HSPs  = $hit->first_child('Hit_hsps')->children('Hsp') ;

	    while(@HSPs){
           
		my $hsp = shift @HSPs ;
		my $pos_st_sb  = $hsp ->first_child('Hsp_hit-from')->text  ;
		my $pos_end_sb = $hsp ->first_child('Hsp_hit-to')->text ;
                my $strand = $hsp -> first_child('Hsp_hit-frame')->text ; 

		if($pos_end_sb  < $pos_st_sb){

		    my $tr = $pos_end_sb ;
		    $pos_end_sb = $pos_st_sb ;
		    $pos_st_sb= $tr ;
                    $strand = "-" ; 

		}
		else{

		    if($strand == 1){
			$strand = "+" ;
		         }
                    elsif($strand == -1){
			$strand = "-" ;
                     }              
		    elsif($strand == 0){
			$strand = "+" ;
		    }
		}

		my $pos_st_qr  = $hsp -> first_child('Hsp_query-from')->text ;
		my $pos_end_qr = $hsp -> first_child('Hsp_query-to')->text ;
		my $identical  = $hsp -> first_child('Hsp_identity')->text ;
		my $hsp_cum_length = $hsp -> first_child('Hsp_align-len')->text ;
		my $hsp_query_length = $pos_end_qr - $pos_st_qr ;
		my $hsp_hit_length =  $pos_end_sb - $pos_st_sb ;
		my $seq_query =$hsp ->first_child('Hsp_qseq')->text ;
		my $seq_target = $hsp ->first_child('Hsp_hseq')->text ;
		my $hit_des =  "NA" ;
              
	      
         
push(@hsp,[  $pos_st_qr, $pos_end_qr, $pos_st_sb, $pos_end_sb, $identical , $hsp_cum_length , $strand, $hsp_query_length, $hsp_hit_length , $seq_query, $seq_target,$hit_des ]) ;

            }

         my @Res = () ;

  my $string = HSP(\@hsp, $query_name, $query_length , $hit_name, $hit_length, \@Res) ;

                  
	 while(@Res){
     
	     my $result = shift @Res ;
             my ($cip_calp, $blat) = split(/§/, $result) ;

          print $ln  $cip_calp;
          print $lnI $blat ;    

	       }
             } 
	  }
	  else{
	      print "No hits found for $query_name\n" ;
	    }
        $twig->purge ; 
           }
      }
 else{

    die "Non Files\n" ;

    }

