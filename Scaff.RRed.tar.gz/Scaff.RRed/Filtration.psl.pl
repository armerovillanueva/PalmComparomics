#!/usr/bin/env perl                                                                                                                                                                     
use strict;
use warnings;
use Getopt::Long qw(GetOptions);

my $psl  = "" ;
my $best = "" ;
my $output = "" ;

GetOptions (
         'p=s' => \$psl,
         'b=s' => \$best,
         'o=s' => \$output, 
   )  or die "Usage:$0 -p psl_input -b IndCovBest_file -o output_file\n" ;


main :{

    if((-s $psl) and (-s $best) and ($output)){
	PslFilt($psl,$best, $output);
    }
    else{
	die "Usage:$0 Non Files\n" ;
    }
 }

 sub  PslFilt {

    my ($psl, $best, $output) = @_ ;

    open( my $ps , '<', $psl ) or die "Can't read file $psl";
    open( my $bt , '<', $best ) or die "Can't read file $best";
    open( my $op , '>', $output ) or die "Can't read file $output";        

    my %best ;

      while(my $ln = <$bt>){
    
          chomp($ln);
	  my @ar  = split /\t/, $ln ;
	  $best{$ar[0]}{$ar[1]} = "";

          }

     
 while(my $ln = <$ps>){
         
         chomp($ln);   
	 my @ar  = split /\t/, $ln ;

  if(exists  $best{$ar[9]}{$ar[13]}){
        print $op $ln,"\n" ;    
               }
         }
      }
