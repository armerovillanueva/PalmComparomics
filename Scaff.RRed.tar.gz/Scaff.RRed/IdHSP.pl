#!/usr/bin/env perl                                                                                                                                                                     
use strict;
use warnings;
use Getopt::Long qw(GetOptions);


# Aim: HSPs identifier
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28  


my $input = "" ;
my $output = "" ;

GetOptions (
         'i=s' => \$input,
         'o=s' => \$output, 
   )  or die "Usage:$0 -i input_file -o output_file\n" ;


main :{

    if( (-s  $input) and ($output) ){
	Rn($input, $output);
         }
    else{
	die "Usage:$0 Non Files\n" ;
        }
      }


  sub Rn {

      my ($in, $op)  = @_; 


      open( my $inp , '<', $in ) or die "Can't read file $in";
      open( my $opt , '>', $op ) or die "Can't read file $op";

      my %Cont;

    while(my $ln = <$inp>){

         chomp($ln);
         my @ar = split(/\t/,$ln);
         my $target = $ar[9] ; 

    if(exists $Cont{$target}){

	my $nm =$Cont{$target} ;
	  $Cont{$target} += 1 ;
	  $ar[9].=".".$nm ;

            }
      else{

	$Cont{$target} = 2 ;
	$ar[9].=".1";

           }

    print $opt join("\t", @ar),"\n" ;

      }
   }
