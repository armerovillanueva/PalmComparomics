#!/usr/bin/env perl                                                                          
use strict;
use warnings;
use Getopt::Long qw(GetOptions);

# Aim:remove space of psl and parameters alignment file
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28  




 my $Input = "" ;
 my $Output  = "" ;

GetOptions (
         'i=s' => \$Input,
         'o=s' => \$Output, 
           )  or die "Usage:$0 -i file_input -o file_output\n" ;


 main :{

    if((-s $Input) and (-f $Output )){
      trim($Input,$Output);   
      }
    else{
      die "Usage:$0 Non Files\n" ;     
       }
    }


 sub trim {                                                                                
 
    my ($input, $output)  = @_ ;                                                                    
    open( my $fl , '<', $input ) or die "Can't read file $input";
    open( my $out , '>', $output ) or die "Can't read file $output";   
     

    while(my $ln = <$fl>){
    
        chomp($ln);
        my @ar = split /\t/, $ln;
        for(@ar){  s/(^\S+).*/$1/  }
        $ln = join("\t", @ar) ;
        print $out $ln,"\n" ;
 
            }

    close($fl);

       }
