#!/usr/bin/env perl                                                             
use strict;
use warnings;
use Bio::Seq;
use Bio::SeqIO;
use Getopt::Long qw(GetOptions);

# Aim: Make fasta file of assembled sequences
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       # License: GPL-3+                                                                                     # Persons: Alix Armero [cre,aut]                                                                      # Versioning: 2017.1.28  





my $one = "" ;
my $frame = "";
my $many = "" ;
my $output = "" ;

GetOptions (
         'o=s' => \$one,
         'f=s'  => \$frame,
         'm=s' => \$many,
    )  or die "Usage:$0 -o one_file -f sequences_file -m many_fasta\n" ;


main :{

    if(  (-f $one) and (-f $frame) and ( -f $many )){
	parsing($one, $frame, $many);
    }
    else{
	die "Usage:$0 Non Files\n" ;
    }
 }


 sub  parsing  {

    my ($one, $frame, $many) = @_  ;  


    open(my $on , '<', $one ) or die "Can't read file $one" ;
    open(my $fr , '<', $frame ) or die "Can't read file $frame" ;

    my $mn = Bio::SeqIO->new(-file => ">>$many", -format => 'fasta' );

    my %Seq ;
   
     while(my $ln = <$fr>){
       
         chomp($ln);
         my ($nm, $seq) = split(/\t/, $ln);     
	 $Seq{$nm}  = $seq ;

           }

  
   while(my $ln = <$on>){

       chomp($ln);
       my @ar  = split(/\t/, $ln);
       my $ct = $ar[1];  
       my $rf = $ar[0] ; 

      if(exists $Seq{$ct}){

   
          my $seq = $Seq{$ct} ;
          my $seq_obj_0 = Bio::Seq->new(-seq => $seq,
                       -display_id => $rf,
                      -alphabet => "protein",
	      );
	  $mn->write_seq($seq_obj_0);

                 }
          else{
        print "Error non sequences for $ct\n" ; 
	  }
        }
     }
