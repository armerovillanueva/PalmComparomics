#!/usr/bin/env perl
use strict;
use warnings;
use File::Temp qw(tempfile);
use IO::Handle;
use Getopt::Long qw(GetOptions);

# Aim:  scaffolding of polypeptides by comparative genomics 
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)   
# License: GPL-3+
# Persons: Alix Armero [cre,aut]
# Versioning: 2017.1.28


my $blast = "" ;
my $identity = "" ;
my $coverage = "" ;
my $message = 0  ; 
my $cover_inf_40 = "" ;
my $output = "" ;
my $SEE = 0;
my $fasta = "" ;

 GetOptions (
 
        'b=s' => \$blast,
         'f=s' => \$fasta,
         'i=s' => \$identity,
         'q=s' => \$coverage,  
         'r=s' => \$cover_inf_40,
         's=s' => \$output,
         )  or die "Usage:$0 -b blast_input  -f proteins_fasta -i identity -q coverage_>40 -r coverage_<40 -s  output\n" ;


main :{

 
   if( (-s $blast)  and ( -s $fasta ) ) {
    
   my ($ic, $idcov) = tempfile();
   my ($ps, $psl_file) = tempfile();
   my ($tm, $tmp) = tempfile(); 
   my ($tmI, $tmpI) = tempfile();
   my ($tmII, $tmpII) = tempfile();
   my ($psb, $psl_best) = tempfile();
   my ($fr, $frame) = tempfile();
   my $best_out = $output.".alignment.parameters" ;
   my $chimeric_polypeptides  = $output.".chimeric_polypeptides" ;   

    $ic->flush ;
    $ps->flush ;
    $tm->flush;
    $tmI->flush; 
    $tmII->flush;
    $psb->flush;
    $fr->flush;  


 &process_cmd("./parsing_blastp.pl -b $blast -i $idcov  -p $psl_file"); 
 
## Identification of potential chimeric polypeptides

 &process_cmd("./Trim.pl -i $idcov -o $tmp");


   close($ic);

 &process_cmd("./BestI.pl -c $tmp -i $identity -q $coverage -r $cover_inf_40 -o $best_out");

    close($tm);

 &process_cmd("./Trim.pl -i $psl_file -o $tmpI");

  &process_cmd("./chimerics.V.pl -b $tmpI -o $chimeric_polypeptides  -v 1");
   
    close($ps);

 &process_cmd("./Filtration.psl.pl -p $tmpI -b $best_out  -o $tmpII");     

   close($tmI) ;

 &process_cmd("./IdHSP.pl -i $tmpII  -o $psl_best"); 

    close($tmII);

 
&process_cmd("./Frame.pl -p $fasta -i $psl_best -o $frame");

  
  
&process_cmd("./Step5.pl -p $psl_best -f $frame -d 10000  -o $output");


   close($psb); 
   
         }
     else{   
print   "Non files $blast $fasta\n" ; 
       }
     }


  sub process_cmd {
  
      my ($cmd) = @_;
      print STDERR "CMD: $cmd\n" unless ($message);

    my $start_time = time();
    my $ret = system("bash", "-c", $cmd);
    my $end_time = time();

    if ($ret) {
        die "Error, cmd: $cmd died with ret $ret";
            }

    print STDERR "CMD finished (" . ($end_time - $start_time) . " seconds)\n" if $SEE;
    return;

   }


