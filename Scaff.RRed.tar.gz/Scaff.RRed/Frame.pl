#!/usr/bin/env perl                                                                                                                                                                     
use strict;
use warnings;
use Bio::Seq;
use Bio::SeqIO;
use Getopt::Long qw(GetOptions);

my $poly = "" ;
my $seqs = "" ;
my $output = "" ;

 GetOptions (
 
         'p=s' => \$poly,
         'i=s' => \$seqs,
         'o=s' => \$output, 
 
        )  or die "Usage:$0 -p polypeptides -i input_file -o output_file\n" ;

main :{

    if( (-s  $poly)  and (-s $seqs  ) and ($output) ){
         Fr( $poly , $seqs, $output);
         }
    else{
	die "Usage:$0 Non Files\n" ;
         }
       }

  sub Fr {

      my ($sq, $pl , $op)  = @_; 

      open( my $inp , '<', $pl ) or die "Can't read file $pl";
      my $sq_input = Bio::SeqIO->new(-file => "<$sq", -format => 'fasta' );
      open( my $opt , '>', $op ) or die "Can't read file $op";
      my %Ct  ;

  while(my $ln = <$inp>){

	    chomp($ln);
            my @ar = split /\t/, $ln ;
            my $nm = $ar[9] ;
               $nm =~  s/(.+).[0-9]+/$1/ ;
	      
        if(exists $Ct{$nm}){
             $Ct{$nm} .=",".$ar[9] ;
	              }
              else{
		  $Ct{$nm} =$ar[9] ;
                   }              
                 }

     while(my $sec = $sq_input->next_seq){

	 my $nm = $sec->id;
	 my $sq = $sec->seq;

           if(exists $Ct{$nm}){

	   my @Hsp = split(/,/, $Ct{$nm}) ;

             while(@Hsp){

               my $hsp = shift @Hsp ; 
               print $opt  $hsp,"\t",$sq,"\n" ; 
	            }
	         }
               }
            }
