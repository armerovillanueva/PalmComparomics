#!/usr/bin/env perl                                                             
use strict;
use warnings;
use XML::Twig;
use Data::Dumper;
use Getopt::Long qw(GetOptions);

# Aim: Identify chimeric sequences
# Copyright (C) 2017-2018 Centre de coopération internationale en recherche agronomique pour le développement (CIRAD)                                                                                       
# License: GPL-3+                                                                                     
# Persons: Alix Armero [cre,aut]                                                                      
# Versioning: 2017.1.28  




### Check length. It verifies if any of the target proteins covers more than 80% of the query protein in this case the protein is declared non-chimeric.


 sub check {
  
     my ($mt , $lon) =  @_; 
     my $ind = 0;

     while((my $Inf= shift @$mt) and ($ind != 1)){

          my @Inseq = split(/§/, $Inf); 
	 #print $inf,"\n" ;

     while(my $inf = shift @Inseq){

       my @in  = split(/,/, $inf); 
       #print  $in[2],"\t",$in[1],"\n" ;
       my $lon_tg = $in[2]-$in[1] ;      
        
         if(($lon_tg/$lon)  >= 0.70){
	     $ind= 1 ;
	        }
            }
       }

###  No chimeric
       if($ind == 1){
	   return  1;
	   }

#### Chimeric 

        else{
	   return 0;
	   }
         }

## Determine whether the same protein or gene is present in all groups          ## The idea is determine if there is a protein present in all groups  


 sub CmpGp { 

    my $Grs = shift @_ ;
    my $Id =  0;
    my $first = shift @$Grs ;
    my @Ft  = split(/§/, $first );
    my %Chim ;  


    while(@Ft){ 
 
	my $ft = shift @Ft ;
	my @inf = split(/,/, $ft );
	$inf[0] =~ s/(.+)\.[0-9]+$/$1/ ;
	$Chim{$inf[0]} = "" ;  

        }

    while(@$Grs){

	my $gr = shift @$Grs ;     
	my @Inf = split(/§/, $gr);
        my %Quim ;
        
	while((@Inf) and (%Chim)){     
         
	    my $inf = shift @Inf ;
	    my @mRNACh = split(/,/, $inf);
	    my $mRNAch = shift @mRNACh ;          
               $mRNAch =~  s/(.+)\.[0-9]+$/$1/ ; 
	    #print $mRNAch,"\n" ;

            if(exists $Chim{$mRNAch} ){
		 $Quim{$mRNAch} = "";
	            }
	         }

         if(%Quim){
	 
             %Chim =  %Quim ;
	  
               }
          else{
	      %Chim = () ;
              } 
            }
   
       if(!keys %Chim){

           my @keys = keys %Chim ;
           #print "Keys\t",join("\t", @keys),"\n" ;
	   return 1 ;

             }  
        else{
          return 0 ; 
            }
         }

  sub Groups {

  my ($Non_red ,$para_overlap ) = @_ ; 
  my $gr = "" ;
 my @groups ;    

  my @pre_ord = map { my @ar = split(/,/, $_) ; [ $ar[0], $ar[1], $ar[2] ]} @$Non_red ;
  my @ord   = sort { $a -> [1] <=> $b -> [1] } @pre_ord ;


  my $ft = shift @ord ;
  my $id_rf = $ft -> [0] ;
  my $ps_in = $ft -> [1] ;  
  my $ps_fn = $ft -> [2] ;
  my %Gr ;
  my $str = join(",", $ft -> [0], $ft -> [1], $ft -> [2]) ;

  while( my $nr  = shift @ord){

       my $id_act = $nr -> [0] ;
       my $ps_in_act = $nr -> [1] ;
       my $ps_fn_act = $nr -> [2] ;
    

## para_overlap. Allows to separate two sequences into two distinct groups, if only if the sequences have an overlap equal to or less than    

        if( ($ps_fn - $ps_in_act) > $para_overlap ){

             $str .="§".join(",", $id_act, $ps_in_act, $ps_fn_act ); 
           
          }
       else{
	   $Gr{$str} = "" ;
           $str = join(",", $id_act, $ps_in_act, $ps_fn_act );
          }

       $ps_fn = $ps_fn_act ;
     }
  
  $Gr{$str} = "" ;

       
      @groups = keys %Gr ; 


   ####
       #print join("\t", @groups),"\n" ;
   ####

    if((scalar @groups) > 1){ 

       my @Cp =  @groups ;
       my $ch = CmpGp(\@groups) ;

       #print "ch\t$ch\n" ;
       
         if($ch == 0){
	      @Cp = () ;
	      }
      
   ### Borrar else
        else{
          return @Cp;
	    }
          }
       }


### Attention. To target protein names was added (.[0-9]+) to differentiate different HSPs from the same target protein



sub  chimerics {

    my ($input, $output, $par_overlap) = @_  ;      
 
    open(my $ip, '<', $input ) or die "Can't read file $input" ;
    open(my $op , '>', $output ) or die "Can't read file $output" ;

  ## Retrieve all targets and alignment positions for each of the query polypeptides
    my $con = 1 ;
    my %PpPos ;

  ## Recover id target proteins and the positions of alignment in the query

    my %Lon ;

    while(my $ln = <$ip>){

        my @ar = split(/\t/, $ln);
        my $query = $ar[9] ;
        my $match = $ar[0] ;
        my $qr_pos_in = $ar[11] ;
        my $qr_pos_fn =$ar[12] ;    
        my $size = $qr_pos_fn - $qr_pos_in ;          
        my $lon_qr = $ar[10]; 
	$Lon{$query} = $lon_qr ;
	#print $match/$size,"\n" ;

        if(($match/$size)  >=  0.50){
    
	  my $target = $ar[13].".$con";
          $con += 1 ;
          my $str = $target.",".$qr_pos_in.",".$qr_pos_fn;       
          $PpPos{$query}{$str} = "" ;           

	      }
         }

    my @Querys = keys %PpPos ;


## recover the longest alignment piece of a given region with  RedNon

    while(@Querys){

	my $qr = shift @Querys ;
        my @Targets =  keys %{$PpPos{$qr}} ;
	my @cp = @Targets ; 
	my @mat = @cp;
	#my $ref = shift @Targets ;

  ### Identify all HSPs of target proteins that do not overlap in the query protein

       my @gr = Groups(\@Targets, $par_overlap);

      if((scalar @gr) > 1){
    
	  my @Cp = @gr ;

          #print "cp\t",join("\t", @cp),"\n" ;  

          my $lon_qr = $Lon{$qr} ;
          my  $in =  check(\@gr, $lon_qr) ;          	  

	  if($in == 0){
          print $op $qr,"\n" ;
	      }
             }
          }
       }


#### Begin main

my $blat = "" ;
my $output = "" ;
my $par_overlap = "" ;

  GetOptions (
         'b=s' => \$blat,
         'o=s' => \$output,
         'v=s' => \$par_overlap,  
       )  or die "Usage:$0 -b blat_input -o output_file -v overlap_allowed \n" ;

#$para_overlap


   if(( -s $blat )  and  ($output)) {

       chimerics($blat, $output, $par_overlap) ;
   
		}
    else{
      die "Usage:$0 Non Files\n" ;
     }
